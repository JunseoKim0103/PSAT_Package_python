
"""
Chapter 4: 모델링 - Gradient Descent

경사하강법을 통해 회귀모형을 적합할 수 있는 모듈을 만들어 보겠습니다.
Model 클래스를 상속받아 사용하겠습니다.
주어진 라이브러리 이외에 다른 라이브러리는 사용하지 않습니다.

1. __init__       : gradient를 계산할 parameter들을 지정하고, 모든 값들을 tensor로 변경합니다.
2. compute_cost   : gradient 계산에 활용되는 손실함수를 계산합니다.
3. comput_gradient: 주어진 반복횟수와 학습률에 따라 회귀계수를 추정합니다.
"""

import torch
import time
import pandas as pd
from model import Model


class GradientDescent():
    def __init__(self):
        """
        :param
        data1   : Model 클래스와 동일
        data2   : Model 클래스와 동일
        """

    # 1. Model 클래스가 LSE 클래스의 부모 클래스가 될 수 있도록 코드를 작성해 주세요. (HINT: 20번째 줄 괄호 안에 코드를 작성하세요.)
    # 2. super()를 통해 Model 클래스의 method와 입력들을 GradientDescent로 가져오세요. (HINT: super().__init__()을 사용하세요.)
    # 3. 필요한 회귀계수의 수만큼 self.theta_i(ex) self.theta_1)와 self.bias를 객체로 만들고, gradient가 흐를 수 있는 tensor를 저장해 주세요.
    #    (HINT: torch.ones()를 사용하고, requires_grad 인자를 알아보세요.)
    # 4. Model 클래스의 self.X_mat의 모든 열들을 분리하여 각 tensor로 저장하세요. (HINT: torch.as_tensor()를 사용하세요.)
    # 5. 회귀계수의 변화 과정을 저장하기 위해 각 회귀계수의 이름(theta_1, bias 등)을 key로 하고 빈 list를 value로 갖는 dictionary를 생성하세요.
    # 6. 손실함수 값의 변화 과정을 저장하기 위해 self.cost_hist에 빈 list를 저장하세요. 그리고 self.cost에 0을 저장하여 초기화하세요.
    # 7. 예측값을 저장하기 위한 빈 객체로 self.pred를 생성하세요.

    def compute_cost(self):
        """
        :return: MSE 값을 반환합니다.
        """

        # 1. self.pred와 실제값 self.y를 사용하여 MSE를 계산하고, self.cost에 저장하여 반환하세요.

    def compute_gradient(self):
        """
        :param
        num_iter   : 반복횟수를 지정합니다.   (형식: int)
        lr         : 학습률을 지정합니다.     (형식: float)
        optimizer  : optimizer를 지정합니다. (형식: torch.optim)
        :return: self.theta, self.cost_hist, self.theta_hist, self.train_pred
        """

        # 1. 입력받은 optimizer로 회귀계수를 업데이트하기 위한 optimizer 객체를 생성하세요. (HINT: optimizer(회귀계수 목록, lr=학습률) 형태입니다.
        # 2. 모형 적합에 소요되는 시간을 측정하기 위해 start 객체에 현재 시간을 저장하세요.
        # 3. num_iter만큼 for문을 반복하여 회귀계수를 적합하세요.
        # 3-1. 각 theta와 대응되는 X의 열들을 곱하여 self.pred에 저장하세요.
        # 3-2. cost를 계산하고, self.cost_hist에 저장하도록 하세요.
        # 3-3. self.theta_hist의 각 key에 대응되는 theta값들을 저장하세요. (HINT: tensor.clone().detach().numpy()로 저장하는 것이 안전합니다.)
        # 3-4. cost를 역전파시키고, optimizer가 알맞은 회귀계수를 추정해나갈 수 있도록 하세요.
        # 3-5. 100번의 Epoch마다 소요된 시간과 손실함수 값을 반환하게 하세요.
        # 4. self.train_pred에 for문의 마지막 self.pred값을 저장하세요. (HINT: tensor.detach().numpy()를 사용하세요.)
        # 5. self.theta에 최종 theta 값을 list 형태로 저장하세요. (HINT: 각 theta 값에 tensor.detach().numpy()를 사용하세요.)
