
"""
Chapter 2: 데이터 전처리 및 시각화

Outlier 제거를 위한 모듈입니다.
주어진 라이브러리 이외에 다른 라이브러리는 사용하지 않습니다.

1. del_outlier: 변수별로 outlier의 index를 추출한 후, 해당 데이터들을 제거합니다.
"""

import pandas as pd


def del_outlier():
    """
    :param
    data   : train 데이터의 X값 (형식: pd.DataFrame)
    y      : train 데이터의 y값 (형식: pd.DataFrame)
    :return: Outlier가 모두 제거된 x값과 y값 (형식: pd.DataFrame)
    """

    # 1. for문을 사용하여 변수별로 outlier의 index를 저장한 후, 중복되는 행들을 처리하여 최종적으로 이상치를 제거하세요.
    # (HINT: for문을 사용하고, 중복되는 행들을 처리하고 위해 set()을 사용하세요.
